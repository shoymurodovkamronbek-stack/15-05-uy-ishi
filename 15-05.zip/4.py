import os
os.system("cls")
class BankHisob:
    def __init__(self, ism, balans=0):
        self.ism = ism
        self.balans = balans

    def deposit(self, summa):
        self.balans += summa

    def yechib_ol(self, summa):
        if summa <= self.balans:
            self.balans -= summa
        else:
            print("Balans yetarli emas")

    def hisob(self):
        return self.balans
b1 = BankHisob("Kamron")
b1.deposit(1000)
b1.yechib_ol(400)
print("Balans:", b1.hisob())