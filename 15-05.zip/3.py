import os
os.system("cls")
class Avtomobil:
    def __init__(self, model, yil, tezlik):
        self.model = model
        self.yil = yil
        self.tezlik = tezlik

    def tezlashtir(self):
        self.tezlik += 10

    def sekinlashtir(self):
        self.tezlik -= 10

    def info(self):
        print(self.model, self.yil, self.tezlik)

a1 = Avtomobil("Cobalt", 2023, 0)
a1.tezlashtir()
a1.tezlashtir()
a1.tezlashtir()
a1.sekinlashtir()
a1.info()