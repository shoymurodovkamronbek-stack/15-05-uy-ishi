import os
os.system("cls")
# 7-masala. Kutubxona tizimi

class Kitob:
    def __init__(self, nomi, muallif):
        self.nomi = nomi
        self.muallif = muallif

class Kutubxona:
    def __init__(self):
        self.kitoblar = []

    def kitob_qoshish(self, kitob):
        self.kitoblar.append(kitob)

    def qidirish(self, nom):
        for kitob in self.kitoblar:
            if kitob.nomi == nom:
                return f"Topildi: {kitob.nomi} - {kitob.muallif}"

        return "Kitob topilmadi"

k1 = Kitob("Python", "Aliyev")
k2 = Kitob("Django", "Valiyev")
k3 = Kitob("Java", "Karimov")

kutubxona = Kutubxona()
kutubxona.kitob_qoshish(k1)
kutubxona.kitob_qoshish(k2)
kutubxona.kitob_qoshish(k3)
print(kutubxona.qidirish("Django"))