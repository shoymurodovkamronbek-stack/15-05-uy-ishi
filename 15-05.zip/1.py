import os
os.system("cls")
class Mahsulot:
    def __init__(self, nom, narx, miqdor):
        self.nom = nom
        self.narx = narx
        self.miqdor = miqdor

    def sotib_ol(self, miqdor):
        if miqdor <= self.miqdor:
            self.miqdor -= miqdor
            print(f"{miqdor} ta mahsulot sotib olindi")
        else:
            print("mahsulot yetarli emas")
    def qolgan_miqdor(self):
        return self.miqdor

m1 = Mahsulot("olma", 5000, 20)
m1.sotib_ol(5)
m1.sotib_ol(3)
print("qolgan mahsulot:", m1.qolgan_miqdor())