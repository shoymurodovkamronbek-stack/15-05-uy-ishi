import os
os.system("cls")
class Kitob:
    def __init__(self, nomi, muallif, sahifa_soni):
        self.nomi = nomi
        self.muallif = muallif
        self.sahifa_soni = sahifa_soni

    def qisqacha(self):
        return f"{self.nomi} - {self.muallif}"

    def katta_kitobmi(self):
        return self.sahifa_soni > 300

k1 = Kitob("Python", "Aliyev", 350)
print(k1.qisqacha())
print(k1.katta_kitobmi())